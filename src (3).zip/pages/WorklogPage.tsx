import { useCallback, useState } from "react";
import { Header } from "../components/layout/Header";
import Toast from "../components/common/Toast";
import WorklogFilterBar from "../components/worklog/WorklogFilterBar";
import WorklogCard from "../components/worklog/WorklogCard";
import WorklogQuickWrite from "../components/worklog/WorklogQuickWrite";
import BoardProgressCard from "../components/worklog/BoardProgressCard";
import { BOARDS, type NewWorklog, type Worklog } from "../constants/worklog";
// 서버 연동
import {
  useBoards,
  useCreateWorklog,
  useCreateWorklogComment,
  useWorklogComments,
  useWorklogs,
} from "../hooks/useWorklogs";
// 진짜 내 이름·번호
import { useMyName } from "../hooks/useMyName";
// ★ 팀원 목록 (댓글 작성자 이름 찾기용)
import { useTeamMembers } from "../hooks/useTeam";
import type { Worklog as ServerWorklog } from "../apis/worklogs";
import type { Board as ServerBoard } from "../apis/boards";
import { getErrorMessage } from "../apis/client";
import { tokenStorage } from "../apis/tokenStorage";

// Date를 "2026-10-26" 모양으로 (한국 시간 기준)
const formatDate = (d: Date) => d.toLocaleDateString("sv-SE");

// ─────────────────────────────────────────────
// 항목(오늘 한 일 등) ↔ 서버 글 하나 바꾸기
// ─────────────────────────────────────────────

// 화면 항목들 → 서버에 보낼 글
// { "오늘 한 일": "A", "막힌 점": "B" } → "## 오늘 한 일\nA\n\n## 막힌 점\nB"
function toServerContent(contents: Record<string, string>): string {
  return Object.entries(contents)
    .filter(([, text]) => text.trim() !== "")
    .map(([title, text]) => `## ${title}\n${text.trim()}`)
    .join("\n\n");
}

// 서버 글 → 화면 항목들 (위와 반대). "## 제목" 줄이 없는 글은 통째로 "자유 형식"
function toContents(content: string): Record<string, string> {
  const parts = content.split(/^## (.+)$/m);
  if (parts.length === 1) return { "자유 형식": content };

  const result: Record<string, string> = {};
  if (parts[0].trim() !== "") result["자유 형식"] = parts[0].trim();
  for (let i = 1; i < parts.length; i += 2) {
    result[parts[i].trim()] = (parts[i + 1] ?? "").trim();
  }
  return result;
}

// 서버 일지 → 화면 일지
function toPageWorklog(w: ServerWorklog, boards: ServerBoard[]): Worklog {
  const created = new Date(w.createdAt);
  const boardName = boards.find((b) => b.id === w.boardId)?.name;
  return {
    id: w.id,
    author: w.authorName,
    // ☆ 작성자 번호 (프로필 사진용)
    authorId: w.authorId,
    date: formatDate(created),
    time: created.toTimeString().slice(0, 5),
    boards: boardName ? [boardName] : [],
    isPublic: w.visibility === "PUBLIC",
    contents: toContents(w.content),
    // 댓글은 카드마다 따로 불러온다
    comments: [],
  };
}

// ─────────────────────────────────────────────
// 댓글을 서버에서 불러와서 카드에 붙여주는 부품
// ─────────────────────────────────────────────
type WorklogCardWithCommentsProps = {
  worklog: Worklog;
  // 내가 쓴 일지인지
  isMine: boolean;
  // 회원 번호 → 이름 (댓글은 서버가 이름을 안 주고 번호만 줘서)
  names: Map<number, string>;
  onError: (message: string) => void;
};

function WorklogCardWithComments({ worklog, isMine, names, onError }: WorklogCardWithCommentsProps) {
  // 비공개 글은 댓글을 받을 수 없으니 요청하지 않는다
  const commentsQuery = useWorklogComments(worklog.isPublic ? worklog.id : null);
  const createComment = useCreateWorklogComment();

  const comments = (commentsQuery.data ?? []).map((c) => ({
    id: c.id,
    // 이름표에서 찾고, 그래도 못 찾으면 "팀원"
    author: names.get(c.authorId) ?? "팀원",
    // ☆ 댓글 작성자 번호 (프로필 사진용)
    authorId: c.authorId,
    content: c.content,
  }));

  const handleAddComment = (worklogId: number, content: string) => {
    createComment.mutate(
      { worklogId, content },
      { onError: (error) => onError(getErrorMessage(error)) }
    );
  };

  return (
    <WorklogCard worklog={{ ...worklog, comments }} isMine={isMine} onAddComment={handleAddComment} />
  );
}

// 빈 목록 안내 상자
type EmptyStateProps = {
  title: string;
  description: string;
  onReset?: () => void;
};

function EmptyState({ title, description, onReset }: EmptyStateProps) {
  return (
    <div className="rounded-lg border border-dashed bg-white py-12 text-center">
      <p className="text-sm font-medium text-neutral-600">{title}</p>
      <p className="mt-1 text-xs text-neutral-400">{description}</p>
      {onReset && (
        <button onClick={onReset} className="mt-4 rounded border px-3 py-1.5 text-xs text-neutral-600">
          필터 초기화
        </button>
      )}
    </div>
  );
}

type ToastState = { id: number; message: string; type: "success" | "info" };

export default function WorklogPage() {
  // 서버 데이터
  const worklogsQuery = useWorklogs();
  const boardsQuery = useBoards();
  const createWorklog = useCreateWorklog();
  // ★ 팀원 전체 (못 불러와도 아래에서 일지 작성자 이름으로 채운다)
  const teamQuery = useTeamMembers();

  // 진짜 내 정보. 회원 번호를 아직 못 불러왔으면 토큰에서 꺼낸 번호를 쓴다
  const { myName, myId: profileId } = useMyName();
  const myId = profileId ?? tokenStorage.getMemberId();

  // 화면 상태
  const [activeTab, setActiveTab] = useState("팀 전체");
  const [board, setBoard] = useState("");
  const [period, setPeriod] = useState("");
  const [periodStart, setPeriodStart] = useState("");
  const [toast, setToast] = useState<ToastState | null>(null);

  const showToast = (message: string, type: "success" | "info" = "info") => {
    setToast((prev) => ({ id: (prev?.id ?? 0) + 1, message, type }));
  };
  const closeToast = useCallback(() => setToast(null), []);

  // 기간을 골랐을 때 시작 날짜를 계산해 둔다
  const handlePeriodChange = (value: string) => {
    setPeriod(value);
    const now = new Date();
    if (value === "이번 주") {
      const start = new Date(now);
      start.setDate(now.getDate() - 6);
      setPeriodStart(formatDate(start));
    } else if (value === "이번 달") {
      setPeriodStart(formatDate(new Date(now.getFullYear(), now.getMonth(), 1)));
    } else {
      setPeriodStart("");
    }
  };

  // 탭·보드·기간을 처음 상태로
  const handleResetFilters = () => {
    setActiveTab("팀 전체");
    setBoard("");
    setPeriod("");
    setPeriodStart("");
  };

  // 서버 일지 → 화면 일지 (최신 글이 위로)
  const serverWorklogs = [...(worklogsQuery.data?.content ?? [])].sort((a, b) =>
    b.createdAt.localeCompare(a.createdAt)
  );
  const boards = boardsQuery.data ?? [];
  const worklogs = serverWorklogs.map((w) => toPageWorklog(w, boards));

  // 내가 쓴 일지 번호들 ("내 일지" 탭, 검은 테두리에 사용)
  const myWorklogIds = new Set(serverWorklogs.filter((w) => w.authorId === myId).map((w) => w.id));

  // ★ 회원 번호 → 이름 표 (뒤에 넣은 것이 앞의 것을 덮어쓴다)
  // ① 팀원 전체 ② 일지 작성자 ③ 나
  const names = new Map<number, string>();
  (teamQuery.data ?? []).forEach((m) => names.set(m.memberId, m.name));
  serverWorklogs.forEach((w) => names.set(w.authorId, w.authorName));
  if (myId !== null && myName) names.set(myId, myName);

  // 작성 → 서버에 저장
  const handleAddWorklog = (data: NewWorklog) => {
    const content = toServerContent(data.contents);
    if (content === "") {
      showToast("항목을 하나 이상 입력해 주세요");
      return;
    }
    createWorklog.mutate(
      {
        // 서버는 제목이 필수라서 날짜로 자동으로 만든다
        title: `${formatDate(new Date())} 업무일지`,
        content,
        visibility: data.isPublic ? "PUBLIC" : "PRIVATE",
      },
      {
        onSuccess: () => showToast("일지를 올렸습니다", "success"),
        onError: (error) => showToast(getErrorMessage(error)),
      }
    );
  };

  // 서버가 비공개 글은 "내 것만" 보내주니까, 받은 글은 전부 볼 수 있는 글이다
  const readableWorklogs = worklogs;

  const visibleWorklogs = readableWorklogs.filter((w) => {
    if (activeTab === "내 일지" && !myWorklogIds.has(w.id)) return false;
    if (board !== "" && board !== "전체" && !w.boards.includes(board)) return false;
    if (periodStart !== "" && w.date < periodStart) return false;
    return true;
  });

  const groupedByBoard = BOARDS.map((b) => ({
    ...b,
    items: visibleWorklogs.filter((w) => w.boards.includes(b.name)),
  })).filter((group) => group.items.length > 0);

  const isFiltered =
    activeTab !== "팀 전체" || (board !== "" && board !== "전체") || (period !== "" && period !== "전체");
  const resetIfFiltered = isFiltered ? handleResetFilters : undefined;

  // 카드 하나 그리기 (내 글인지 같이 넘긴다)
  const renderCard = (w: Worklog) => (
    <WorklogCardWithComments
      key={w.id}
      worklog={w}
      isMine={myWorklogIds.has(w.id)}
      names={names}
      onError={showToast}
    />
  );

  // 왼쪽 목록에 무엇을 보여줄지
  const renderList = () => {
    if (worklogsQuery.isPending) {
      return <p className="rounded-lg bg-white py-12 text-center text-sm text-neutral-400">일지를 불러오는 중...</p>;
    }
    if (worklogsQuery.isError) {
      return (
        <p className="rounded-lg bg-white py-12 text-center text-sm text-red-500">
          {getErrorMessage(worklogsQuery.error)}
        </p>
      );
    }

    if (readableWorklogs.length === 0) {
      return (
        <EmptyState
          title="아직 작성된 일지가 없습니다"
          description="오른쪽 '오늘의 일지 쓰기'에서 첫 일지를 남겨보세요"
          onReset={resetIfFiltered}
        />
      );
    }

    if (activeTab === "보드별 모아보기") {
      if (groupedByBoard.length === 0) {
        return (
          <EmptyState
            title="보드 태그가 달린 일지가 없습니다"
            description="일지를 쓸 때 보드 태그를 달면 보드별로 모아볼 수 있어요"
            onReset={resetIfFiltered}
          />
        );
      }
      return groupedByBoard.map((group) => (
        <section key={group.name} className="flex flex-col gap-3">
          <h3 className="flex items-center gap-2 text-sm font-semibold">
            <span className={`h-2 w-2 rounded-full ${group.dotColor}`} />
            {group.name}
            <span className="text-xs font-normal text-neutral-400">{group.items.length}개</span>
          </h3>
          {group.items.map(renderCard)}
        </section>
      ));
    }

    if (visibleWorklogs.length === 0) {
      return (
        <EmptyState
          title="선택한 조건에 맞는 일지가 없습니다"
          description="탭이나 보드·기간 필터를 바꿔 보세요"
          onReset={handleResetFilters}
        />
      );
    }

    return visibleWorklogs.map(renderCard);
  };

  return (
    <div className="flex min-h-full flex-col">
      <Header title="업무일지" subtitle="자율 작성 · 작성 알림 없음 · 공개/비공개를 글마다 선택" />

      <div className="p-6">
        <div className="mb-4">
          <WorklogFilterBar
            activeTab={activeTab}
            onTabChange={setActiveTab}
            board={board}
            onBoardChange={setBoard}
            period={period}
            onPeriodChange={handlePeriodChange}
          />
        </div>

        <div className="flex flex-col gap-4 lg:flex-row">
          {/* 왼쪽: 일지 목록 */}
          <main className="flex min-w-0 flex-1 flex-col gap-4">{renderList()}</main>

          {/* 오른쪽: 작성 카드 + 보드별 진행 기록 */}
          <aside className="flex w-full flex-col gap-4 self-start lg:w-80">
            <WorklogQuickWrite onSubmit={handleAddWorklog} />
            <BoardProgressCard worklogs={readableWorklogs} />
          </aside>
        </div>
      </div>

      {toast && <Toast key={toast.id} message={toast.message} type={toast.type} onClose={closeToast} />}
    </div>
  );
}