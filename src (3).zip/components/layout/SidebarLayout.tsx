// Navigate: 화면에 그려지는 순간 다른 주소로 보내주는 부품
import { useEffect } from "react";
import { Navigate, Outlet, useNavigate, useLocation } from "react-router-dom";
import { Sidebar } from "./Sidebar";

// ★ 토큰이 저장된 이름 (tokenStorage.ts와 친구 api/client.ts가 같이 쓰는 이름)
const ACCESS_TOKEN_KEY = "pvweb:accessToken";

// ★ 저장된 토큰이 있는지 확인한다
// try: 개인정보 보호 모드 등에서 localStorage를 못 쓰면 에러가 나서, 그때는 "없음"으로 본다
const hasAccessToken = () => {
  try {
    return Boolean(localStorage.getItem(ACCESS_TOKEN_KEY));
  } catch {
    return false;
  }
};

interface SidebarLayoutProps {
  todayTaskCount?: number;
  assignmentCount?: number;
  onNavigate?: (menuName: string) => void;
  onOpenAddModal?: () => void;
}

export default function SidebarLayout({
  todayTaskCount = 0,
  assignmentCount = 0,
  onNavigate,
  onOpenAddModal,
}: SidebarLayoutProps) {
  const navigate = useNavigate();
  const location = useLocation();

  // ★ 이 레이아웃은 화면 높이(h-screen)에 딱 맞고, 스크롤은 안쪽 영역이 맡는다.
  // 그래서 이 레이아웃이 떠 있는 동안에는 브라우저 페이지 전체 스크롤을 막아서,
  // 레이아웃 아래에 흰 빈 공간이 생기지 않게 한다.
  // (입장 화면 같은 다른 페이지에는 영향이 없도록, 이 화면을 떠날 때 원래대로 돌려둔다)
  useEffect(() => {
    const html = document.documentElement;
    const body = document.body;
    const prevHtmlOverflow = html.style.overflow;
    const prevBodyOverflow = body.style.overflow;

    html.style.overflow = "hidden";
    body.style.overflow = "hidden";
    // 이미 아래로 스크롤된 상태에서 막히면 레이아웃이 위로 밀려 보이므로 맨 위로 돌려둔다
    window.scrollTo(0, 0);

    return () => {
      html.style.overflow = prevHtmlOverflow;
      body.style.overflow = prevBodyOverflow;
    };
  }, []);

  // ★ 문지기: 토큰이 없으면(입장 전) 입장 화면으로 보낸다
  // replace: 뒤로 가기를 눌러도 이 화면으로 다시 오지 않게 기록을 바꿔치기한다
  // (훅을 모두 부른 뒤에 return해야 해서 여기에 둔다)
  if (!hasAccessToken()) {
    return <Navigate to="/invite" replace />;
  }

  // 지금 주소를 보고 사이드바에서 어떤 메뉴에 불을 켤지 정한다
  const getActiveMenu = (pathname: string) => {
    if (pathname.startsWith("/today") || pathname === "/") return "오늘 할 일";
    if (pathname.startsWith("/calendar")) return "통합 캘린더";
    if (pathname.startsWith("/activity")) return "활동";
    if (pathname.startsWith("/archive") || pathname.startsWith("/editor"))
      return "정리글 아카이브";
    if (pathname.startsWith("/questions")) return "면접 질문 뱅크";
    if (pathname.startsWith("/assignments")) return "과제 · 역량맵";
    // /worklog 주소면 "업무일지"에 불을 켠다
    if (pathname.startsWith("/worklog")) return "업무일지";
    if (pathname.startsWith("/members")) return "팀원 관리";
    if (pathname.startsWith("/weekly-report") || pathname.startsWith("/report"))
      return "주간 리포트";
    if (pathname.startsWith("/invite")) return "팀원 초대";
    // 설정 화면은 사이드바 아래 내 프로필 영역으로 들어가서 거기에 불을 켠다
    if (pathname.startsWith("/settings")) return "설정";
    return "";
  };

  // 사이드바 메뉴를 눌렀을 때 해당 주소로 이동한다
  const handleNavigate = (menuName: string) => {
    if (onNavigate) {
      onNavigate(menuName);
      return;
    }

    switch (menuName) {
      case "오늘 할 일":
        navigate("/today");
        break;
      case "통합 캘린더":
        navigate("/calendar");
        break;
      case "활동":
        navigate("/activity");
        break;
      case "정리글":
      case "아카이브":
      case "정리글 아카이브":
        navigate("/archive");
        break;
      case "면접 질문 뱅크":
        navigate("/questions");
        break;
      case "과제 · 역량맵":
        navigate("/assignments");
        break;
      // 업무일지 → /worklog
      case "업무일지":
        navigate("/worklog");
        break;
      case "팀원 관리":
        navigate("/members");
        break;
      case "주간 리포트":
      case "주간리포트":
        navigate("/weekly-report");
        break;
      case "팀원 초대":
        navigate("/invite");
        break;
      case "설정":
        navigate("/settings");
        break;
      default:
        break;
    }
  };

  return (
    // relative: 이 레이아웃 안의 absolute 요소가 바깥으로 삐져나가 페이지 높이를 늘리지 못하게 한다
    <div className="relative flex h-screen w-full overflow-hidden bg-[#f7f7f8] font-pretendard">
      <Sidebar
        activeMenu={getActiveMenu(location.pathname)}
        todayTaskCount={todayTaskCount}
        assignmentCount={assignmentCount}
        onNavigate={handleNavigate}
      />
      <div className="flex flex-1 flex-col overflow-y-auto">
        <Outlet context={{ onOpenAddModal }} />
      </div>
    </div>
  );
}
